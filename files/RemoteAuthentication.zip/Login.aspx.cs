﻿using System;
using System.Web.UI;

namespace RemoteAuthentication
{
	public partial class Login : Page
	{
		protected void OpenCatalog(object sender, EventArgs e)
		{
			// Create token & store in database, hardcoded in this case
			Session["Token"] = "4a17ec22-dbf9-4bd7-84d8-31531a31f138";

			// Redirect user to desired catalog, send token along
			Response.Redirect(Request.QueryString["CatalogUrl"] + "?RemoteAuthenticationToken=" + Session["Token"]);
		}
	}
}