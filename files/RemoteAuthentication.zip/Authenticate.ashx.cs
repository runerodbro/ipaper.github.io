﻿using System.Web;
using System.Web.SessionState;

namespace RemoteAuthentication
{
	public class Authenticate : IHttpHandler, IRequiresSessionState
	{
		public void ProcessRequest(HttpContext context)
		{
			string catalogUrl = context.Request.Form["CatalogUrl"];
			string userIP = context.Request.Form["UserIP"];
			string authenticationMode = context.Request.Form["AuthenticationMode"];
			bool allowedAccess = false;

			switch(authenticationMode)
			{
				case "Credentials":
					allowedAccess = validateCredentials(context.Request.Form["Username"], context.Request.Form["Password"], catalogUrl, userIP);
					break;

				case "Token":
					allowedAccess = validateToken(context.Request.Form["Token"], catalogUrl, userIP);
					break;
			}

			writeResponse(context, allowedAccess);
		}

		private void writeResponse(HttpContext context, bool allowedAccess)
		{
			if (allowedAccess)
			{
				context.Response.Write(@"
					<RemoteAuthentication>
						<AccessAllowed>true</AccessAllowed>
					</RemoteAuthentication>");
			}
			else
			{
				context.Response.Write(@"
					<RemoteAuthentication>
						<AccessAllowed>false</AccessAllowed>
					</RemoteAuthentication>");
			}
		}

		private bool validateCredentials(string username, string password, string catalogUrl, string userIP)
		{
			// We might validate whether the specific user has access to the specifically requested catalogUrl.
			// In this case we've hardcoded the username/password combination John/Doe.

			return username == "John" && password == "Doe";
		}

		private bool validateToken(string token, string catalogUrl, string userIP)
		{
			// Validate the token against token stored in session/database/etc.

			return token == "4a17ec22-dbf9-4bd7-84d8-31531a31f138";
		}

		public bool IsReusable
		{
			get { return true; }
		}
	}
}